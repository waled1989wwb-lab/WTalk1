package com.wtalk.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.MotionEvent;
import android.widget.*;

public class MainActivity extends Activity {
    private final int navy = Color.rgb(15, 23, 42);
    private final int blue = Color.rgb(37, 99, 235);
    private LinearLayout root;
    private String selected = "أحمد";
    private TextView status;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showContacts();
    }

    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }

    private void setup(String title) {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 36, 28, 28);
        root.setBackgroundColor(navy);
        TextView heading = text("W-Talk", 30, Color.WHITE);
        heading.setTypeface(null, Typeface.BOLD);
        root.addView(heading);
        TextView sub = text(title, 16, Color.LTGRAY);
        sub.setPadding(0, 6, 0, 28);
        root.addView(sub);
        setContentView(root);
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(17);
        return b;
    }

    private void showContacts() {
        setup("اختر الشخص الذي تريد التحدث معه");
        addContact("أحمد  •  متصل");
        addContact("سارة  •  متصلة");
        addContact("محمد  •  غير متصل");
        Button info = button("معلومات النسخة التجريبية");
        info.setOnClickListener(v -> new AlertDialog.Builder(this)
            .setTitle("W-Talk - النسخة 0.1")
            .setMessage("هذه نسخة أولية للواجهة فقط. الاتصال الصوتي الحقيقي يحتاج خادم تنسيق واتصال WebRTC، وسيضاف في مرحلة لاحقة.")
            .setPositiveButton("حسناً", null).show());
        root.addView(info);
    }

    private void addContact(String label) {
        Button b = button(label);
        b.setAllCaps(false);
        b.setOnClickListener(v -> {
            if (label.contains("غير متصل")) {
                Toast.makeText(this, "هذا المستخدم غير متصل حالياً", Toast.LENGTH_SHORT).show();
            } else {
                selected = label.split(" ")[0];
                showTalk();
            }
        });
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.bottomMargin = 14;
        root.addView(b, p);
    }

    private void showTalk() {
        setup("اتصال فردي");
        TextView who = text("المستخدم المحدد: " + selected, 20, Color.WHITE);
        who.setPadding(0, 20, 0, 18);
        root.addView(who);

        status = text("جاهز للتحدث", 17, Color.rgb(134, 239, 172));
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, 20, 0, 20);
        root.addView(status);

        Button ptt = button("اضغط باستمرار للتحدث");
        ptt.setTextColor(Color.WHITE);
        ptt.setBackgroundTintList(android.content.res.ColorStateList.valueOf(blue));
        ptt.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                status.setText("يتم الضغط على زر التحدث");
                return true;
            } else if (event.getAction() == MotionEvent.ACTION_UP ||
                       event.getAction() == MotionEvent.ACTION_CANCEL) {
                status.setText("انتهى الضغط — جاهز");
                return true;
            }
            return true;
        });
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, 180);
        p.topMargin = 35;
        root.addView(ptt, p);

        TextView note = text("تنبيه: نقل الصوت الفعلي غير مفعّل في هذه النسخة.", 14, Color.LTGRAY);
        note.setPadding(0, 24, 0, 24);
        root.addView(note);

        Button back = button("العودة إلى جهات الاتصال");
        back.setOnClickListener(v -> showContacts());
        root.addView(back);
    }
}
